# MYRA AI — JARVIS-style Android Assistant (GitHub source)

এই ZIP-টি Android/Kotlin source project। GitHub Actions দিয়ে debug APK build করার workflow আছে।

## GitHub-এ APK build
1. ZIP extract করুন।
2. GitHub-এ নতুন repository তৈরি করুন।
3. Extract করা project-এর ভেতরের সব ফাইল repository root-এ upload করুন—`app`, `gradle`, `.github`, `gradlew`, `build.gradle`, `settings.gradle` ইত্যাদি।
4. GitHub-এর **Actions** tab খুলুন।
5. **Build MYRA Android APK** workflow নির্বাচন করে **Run workflow** চাপুন।
6. Workflow সফল হলে run-এর **Artifacts** থেকে `MYRA-debug-apk` download করুন।
7. Artifact ZIP extract করে `app-debug.apk` ফোনে install করুন।

## এই source-এ বর্তমানে কী আছে
- Android/Kotlin app shell, Home screen, animated orb ও waveform
- Gemini Live WebSocket voice integration-এর source
- Text chat input ও SEND
- Voice state handling, audio recorder/player ও VAD scaffolding
- App launching / command parsing / accessibility automation scaffolding
- Flashlight, volume, YouTube/Spotify command handling-এর কিছু code path
- Settings screen-এ Gemini API key, personality, voice engine ও call announce preferences
- Accessibility, overlay, app-lock/biometric ও call-related source components
- GitHub Actions debug APK workflow

## নতুন JARVIS Control Center
Settings থেকে **OPEN JARVIS CONTROL CENTER** চাপলে:
- Installed app chooser দিয়ে app open
- Camera flashlight API দিয়ে torch toggle
- Media volume up/down
- Wi-Fi/network এবং display settings shortcut
- Camera open, Google web search
- Local notification reminder এবং Android alarm UI
- Theme, avatar/orb, language ও personality preference save
- Notification access, Accessibility, overlay এবং app permission settings shortcut

Notification Reader service Android Notification Access grant এবং MYRA-র message-reading toggle ছাড়া কোনো notification পড়ে না। Auto-reply ডিফল্টে OFF; app allowlist ও explicit opt-in ছাড়া reply করে না। Reply শুধুমাত্র notification-এ supported RemoteInput action থাকলে কাজ করবে।

## গুরুত্বপূর্ণ: কী এখনো সম্পূর্ণ/যাচাইকৃত নয়
স্ক্রিনশটে দেখানো সব Settings Studio item এই Android source-এ পূর্ণাঙ্গভাবে নেই। বিশেষ করে:
- Themes Studio-এর সম্পূর্ণ theme switching
- Avatar library, 3D facial animation ও lip-sync
- Mira logo-orb/particle-sphere selector
- Hey MYRA wake-word detector ও battery-optimized always-on listening (এখনও অসম্পূর্ণ; screen off/lock অবস্থায় নির্ভরযোগ্য wake-word চালাতে on-device model এবং বাস্তব ডিভাইস পরীক্ষা প্রয়োজন)
- WhatsApp/SMS notification reading ও direct auto-reply end-to-end
- Reliable natural-language device control across all phone brands
- Phone lock/unlock automation: Android policy/device-admin restrictions অনুযায়ী সীমিত
- Complete multilingual Bangla/Hindi/English voice UX and device testing

এই ফিচারগুলোর UI বা class-এর কিছু অংশ থাকলেও, শুধু screen/setting দেখা মানে feature বাস্তবে কাজ করছে—এমন নয়। এগুলো আলাদা করে implement, integrate এবং বাস্তব Android device-এ test করতে হবে।

## Android permission ও safety
- Microphone, Accessibility, Notification access, Overlay, Camera/Flashlight এবং call/SMS permissions প্রয়োজন অনুযায়ী Android Settings-এ user-কে নিজে enable করতে হবে।
- Accessibility permission শক্তিশালী। শুধু নিজের বিশ্বস্ত app-এ দিন।
- WhatsApp/SMS auto-reply ডিফল্টে OFF রাখা উচিত; app/contact allowlist এবং send করার আগে confirmation ব্যবহার করুন।
- MYRA Android-এর secure lock PIN/pattern পড়তে পারবে না। MYRA-এর নিজস্ব app lock আর phone lock এক জিনিস নয়।
- Background microphone service Android version, notification, battery optimization এবং user permission-এর ওপর নির্ভর করে; সব ফোনে ২৪/৭ চলার নিশ্চয়তা নেই।
- Gemini API key public GitHub repository-তে commit করবেন না। App-এর Settings-এ local device-এ দিন। Public release-এর জন্য backend proxy/key management দরকার।

## Build verification
এই environment-এ `./gradlew assembleDebug` চালিয়ে দেখা হয়েছে, কিন্তু Gradle distribution download করতে network/DNS পাওয়া যায়নি (`UnknownHostException: services.gradle.org`)। তাই APK build সফল হয়েছে বলে দাবি করা হচ্ছে না। GitHub Actions-এর log-ই প্রকৃত build result জানাবে।


## স্ক্রিন বন্ধ/লক অবস্থায় “Hey MYRA”

ফোন চালু আছে কিন্তু screen off বা lock থাকলে MYRA-কে wake word দিয়ে জাগানোর লক্ষ্য রাখা হয়েছে। এই ZIP-এ wake-word detection model এখনো যুক্ত নেই; তাই “Hey MYRA” বলে screen off থেকে অ্যাপ জেগে উঠবে—এমন নিশ্চয়তা দেওয়া হচ্ছে না। Android-এ microphone foreground service, user-granted microphone permission, battery optimization exception এবং নির্দিষ্ট ফোনে পরীক্ষা প্রয়োজন। ফোন পুরোপুরি Power Off থাকলে সাধারণ Android app নিজে থেকে voice command শুনে ফোন চালু করতে পারে না।
