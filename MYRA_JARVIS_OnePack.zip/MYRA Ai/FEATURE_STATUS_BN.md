# MYRA Feature Status (সৎ অবস্থা)

## Source-এ আগে থেকেই থাকা / আংশিক প্রস্তুত
- Android assistant main screen, animated orb ও waveform
- Chat message list এবং Gemini Live voice service integration
- Settings-এ Gemini key, personality, voice engine, live mode ও call announce controls
- App launch / accessibility automation scaffolding
- Call monitoring / caller announce related code
- Biometric prompt, app pattern-lock related screens/classes
- Floating assistant / overlay related classes
- Text chat input + SEND button (এই package-এ যোগ করা হয়েছে)

## এখনো আলাদা করে implement, integrate ও device-test করতে হবে
- 4টি বাস্তব 3D girl avatar, facial rig, lip-sync ও avatar selector
- 4টি সম্পূর্ণ theme palette এবং settings থেকে live theme switch
- Reliable offline wake-word detection ("Hey MYRA") এবং battery-optimized background operation
- Speaker verification / voice biometric enrollment; voice alone-কে security lock হিসেবে ধরা যাবে না
- WhatsApp notification read/reply integration; WhatsApp-এর নিজস্ব policy ও notification access সীমা মানতে হবে
- SMS read/reply এবং call answer/end flow-এর permission, role/default-app ও confirmation tests
- Girlfriend Mode-এর সম্পূর্ণ conversational state/personality
- Coding mode ও generated Android project workflow
- Phone lock action-এর জন্য supported DevicePolicyManager flow; user must explicitly grant device-admin privilege

## নিরাপত্তা
- Android screen lock pattern/PIN MYRA read করতে পারবে না।
- MYRA-এর নিজস্ব app lock আলাদা; phone lock action Android Device Admin policy ও user consent সাপেক্ষে।
- Call/SMS পাঠানো, উত্তর দেওয়া বা screen control-এর আগে confirmation রাখা উচিত।
- Voice biometric spoofing-এর ঝুঁকি আছে; গুরুত্বপূর্ণ কাজের জন্য Android BiometricPrompt/PIN ব্যবহার করুন।
