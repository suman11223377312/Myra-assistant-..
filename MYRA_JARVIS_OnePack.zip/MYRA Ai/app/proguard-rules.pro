# MYRA ProGuard rules
# Keep this file for project-specific release rules.
