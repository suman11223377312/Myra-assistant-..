package com.myra.assistant.ui.main

import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.myra.assistant.service.MyraReminderReceiver
import java.util.Calendar

/**
 * MYRA JARVIS Control Center.
 * Controls that Android exposes through public intents/APIs are implemented here.
 * Privileged actions always open Android settings or require explicit user action.
 */
class JarvisControlActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("myra_prefs", Context.MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 8, 18)
        window.navigationBarColor = Color.BLACK
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(5, 5, 12)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(32))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("MYRA  •  JARVIS CONTROL CENTER", 24, Color.rgb(0, 229, 255)))
        page.addView(label("Phone actions, voice preferences and smart tools", 13, Color.LTGRAY))
        status = label("Ready. Choose an action below.", 13, Color.GREEN)
        status.setPadding(0, dp(12), 0, dp(12))
        page.addView(status)

        section(page, "QUICK PHONE CONTROL")
        addButton(page, "Open an installed app") { chooseApp() }
        addButton(page, "Flashlight ON / OFF") { toggleTorch() }
        addButton(page, "Volume up") { adjustVolume(AudioManager.ADJUST_RAISE) }
        addButton(page, "Volume down") { adjustVolume(AudioManager.ADJUST_LOWER) }
        addButton(page, "Wi-Fi / Bluetooth / network settings") { openSettings(Settings.ACTION_WIRELESS_SETTINGS) }
        addButton(page, "Display & brightness settings") { openSettings(Settings.ACTION_DISPLAY_SETTINGS) }
        addButton(page, "Open camera") { launchIntent(Intent("android.media.action.IMAGE_CAPTURE")) }
        addButton(page, "Search the web") {
            val q = EditText(this).apply { hint = "What should MYRA search?" }
            AlertDialog.Builder(this).setTitle("Web search").setView(q)
                .setPositiveButton("Search") { _, _ ->
                    val value = q.text.toString().trim()
                    if (value.isNotEmpty()) launchIntent(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(value))))
                }.setNegativeButton("Cancel", null).show()
        }

        section(page, "REMINDERS")
        addButton(page, "Create a reminder") { createReminder() }
        addButton(page, "Set an alarm") {
            val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_MESSAGE, "MYRA reminder")
            launchIntent(i)
        }

        section(page, "MYRA STUDIO")
        addButton(page, "Choose interface theme") { chooseTheme() }
        addButton(page, "Choose Mira avatar style") { chooseAvatar() }
        addButton(page, "Choose assistant language") { chooseLanguage() }
        addButton(page, "Voice / personality settings") { choosePersonality() }
        addButton(page, "Wake word settings") { chooseWakeWord() }

        section(page, "PRIVACY & AUTOMATION")
        addButton(page, "Enable notification reading / reply settings") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        addButton(page, "Accessibility automation settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(page, "App overlay permission") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        addButton(page, "App permissions") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        addButton(page, "Stop / manage background listening") {
            AlertDialog.Builder(this).setTitle("MYRA microphone")
                .setMessage("Always-listening mode uses the microphone and must show an Android foreground notification. You can stop MYRA from its persistent notification or Android app settings.")
                .setPositiveButton("App settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                }.setNegativeButton("Close", null).show()
        }

        page.addView(label("Safety: MYRA cannot read your Android lock PIN/pattern or bypass secure lock. Calls, messages and sensitive actions should be confirmed by you.", 12, Color.LTGRAY).apply {
            setPadding(0, dp(18), 0, 0)
        })
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(label(title, 13, Color.rgb(255, 70, 130)).apply {
            setPadding(0, dp(22), 0, dp(8))
        })
    }

    private fun label(text: String, size: Int, color: Int) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
    }

    private fun addButton(parent: LinearLayout, text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(45, 35, 78))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        parent.addView(b, lp)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun openSettings(action: String) = launchIntent(Intent(action))

    private fun launchIntent(intent: Intent) {
        try {
            if (intent.resolveActivity(packageManager) != null) startActivity(intent)
            else status.text = "This action is not supported on this phone."
        } catch (e: Exception) { status.text = "Could not open: ${e.localizedMessage}" }
    }

    private fun chooseApp() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val names = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Open app").setItems(names) { _, which ->
            val app = apps[which]
            val launch = pm.getLaunchIntentForPackage(app.packageName)
            if (launch != null) launchIntent(launch)
        }.setNegativeButton("Cancel", null).show()
    }

    private fun toggleTorch() {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { status.text = "This phone has no flash."; return }
            val on = prefs.getBoolean("torch_on", false)
            manager.setTorchMode(id, !on)
            prefs.edit().putBoolean("torch_on", !on).apply()
            status.text = if (!on) "Flashlight turned ON." else "Flashlight turned OFF."
        } catch (e: Exception) { status.text = "Flashlight failed: ${e.localizedMessage}" }
    }

    private fun adjustVolume(direction: Int) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        status.text = "Media volume adjusted."
    }

    private fun chooseTheme() {
        val names = arrayOf("Aurora Purple", "Neon Pink", "Deep Blue", "Ember Red", "Neon Sky")
        val values = arrayOf("aurora", "pink", "blue", "ember", "sky")
        AlertDialog.Builder(this).setTitle("MYRA theme").setSingleChoiceItems(names, values.indexOf(prefs.getString("theme", "aurora"))) { dialog, which ->
            prefs.edit().putString("theme", values[which]).apply()
            status.text = "${names[which]} saved. Reopen Home to refresh."
            dialog.dismiss()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseAvatar() {
        val names = arrayOf("Original Mira", "Neon Particle Sphere", "Deep Blue Star Sphere", "Ember Logo Orb", "Neon Sky Logo Orb")
        val values = arrayOf("original", "particle", "blue_sphere", "ember", "sky")
        AlertDialog.Builder(this).setTitle("Mira avatar / orb").setSingleChoiceItems(names, values.indexOf(prefs.getString("avatar", "original"))) { dialog, which ->
            prefs.edit().putString("avatar", values[which]).apply()
            status.text = "${names[which]} saved as Home preference."
            dialog.dismiss()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseLanguage() {
        val names = arrayOf("বাংলা", "Hindi", "English", "Hinglish")
        val values = arrayOf("bn", "hi", "en", "hinglish")
        AlertDialog.Builder(this).setTitle("Assistant language").setSingleChoiceItems(names, values.indexOf(prefs.getString("language", "hinglish"))) { dialog, which ->
            prefs.edit().putString("language", values[which]).apply()
            status.text = "${names[which]} saved. Gemini prompt will use this preference after reconnect."
            dialog.dismiss()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun choosePersonality() {
        val names = arrayOf("JARVIS Professional", "Friendly Companion", "Girlfriend-style warmth")
        val values = arrayOf("professional", "friendly", "gf")
        AlertDialog.Builder(this).setTitle("MYRA personality").setSingleChoiceItems(names, values.indexOf(prefs.getString("personality_mode", "gf"))) { dialog, which ->
            prefs.edit().putString("personality_mode", values[which]).apply()
            status.text = "${names[which]} saved."
            dialog.dismiss()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseWakeWord() {
        val enabled = prefs.getBoolean("wake_word_enabled", false)
        AlertDialog.Builder(this).setTitle("Hey MYRA wake word")
            .setMessage("Wake-word detection is not yet implemented in this build. Always-on microphone recognition requires an on-device wake-word model and battery/device testing. Do not enable a fake switch.")
            .setPositiveButton("Understood", null).show()
    }

    private fun createReminder() {
        val title = EditText(this).apply { hint = "Reminder text" }
        val hour = EditText(this).apply { hint = "Hour (0-23)"; inputType = 2 }
        val minute = EditText(this).apply { hint = "Minute (0-59)"; inputType = 2 }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), 0); addView(title); addView(hour); addView(minute) }
        AlertDialog.Builder(this).setTitle("Reminder today").setView(box)
            .setPositiveButton("Schedule") { _, _ ->
                val h = hour.text.toString().toIntOrNull()
                val m = minute.text.toString().toIntOrNull()
                val t = title.text.toString().trim()
                if (t.isEmpty() || h == null || h !in 0..23 || m == null || m !in 0..59) { status.text = "Enter a reminder and valid time."; return@setPositiveButton }
                val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h!!); set(Calendar.MINUTE, m!!); set(Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
                val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val pi = PendingIntent.getBroadcast(this, (t + h + m).hashCode(), Intent(this, MyraReminderReceiver::class.java).putExtra("title", t), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                else alarm.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                status.text = "Reminder scheduled for ${String.format("%02d:%02d", h, m)}."
            }.setNegativeButton("Cancel", null).show()
    }
}
