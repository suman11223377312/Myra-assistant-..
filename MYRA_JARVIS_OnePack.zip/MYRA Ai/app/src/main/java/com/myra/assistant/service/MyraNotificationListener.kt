package com.myra.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import android.util.Log
import android.app.RemoteInput
import java.util.Locale

/**
 * Reads notifications only after the user grants Android Notification Access
 * and enables MYRA's message-reading preference. Auto-reply is separately opt-in.
 */
class MyraNotificationListener : NotificationListenerService() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { result ->
            ttsReady = result == TextToSpeech.SUCCESS
            tts?.language = Locale.getDefault()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val p = getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        if (!p.getBoolean("message_reading_enabled", false)) return
        val allowed = setOf("com.whatsapp", "com.whatsapp.w4b", "com.google.android.apps.messaging", "org.telegram.messenger")
        if (sbn.packageName !in allowed) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() || body.isBlank()) return
        if (ttsReady) tts?.speak("Message from $title. $body", TextToSpeech.QUEUE_ADD, null, "myra-${sbn.id}-${sbn.postTime}")

        // Direct replies are OFF by default and only attempted when user has explicitly enabled it.
        if (p.getBoolean("auto_reply_enabled", false) &&
            p.getBoolean("auto_reply_${sbn.packageName}", false)) {
            val replyText = p.getString("auto_reply_text", "I am busy right now. I will reply soon.") ?: return
            val action = sbn.notification.actions?.firstOrNull { a ->
                a.remoteInputs?.isNotEmpty() == true
            } ?: return
            val remoteInputs = action.remoteInputs ?: return
            val fillIn = android.content.Intent()
            val results = android.os.Bundle()
            remoteInputs.forEach { results.putCharSequence(it.resultKey, replyText) }
            RemoteInput.addResultsToIntent(remoteInputs, fillIn, results)
            try {
                action.actionIntent.send(this, 0, fillIn)
            } catch (e: Exception) {
                Log.w("MYRA_NOTIFY", "Reply action not supported: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
