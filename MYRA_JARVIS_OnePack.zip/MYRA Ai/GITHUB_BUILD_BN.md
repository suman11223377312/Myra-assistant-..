# GitHub-এ MYRA APK Build

1. ZIP extract করুন।
2. GitHub-এ `MYRA` নামে একটি Public বা Private repository তৈরি করুন।
3. Extract করা project-এর সব ফাইল (যেমন `app`, `gradle`, `.github`, `build.gradle`, `settings.gradle`, `gradlew`) repository root-এ upload করুন।
4. `Actions` tab খুলুন।
5. `Build MYRA Android APK` workflow নির্বাচন করুন।
6. `Run workflow` চাপুন।
7. Build শেষ হলে run page-এর `Artifacts` অংশ থেকে `MYRA-debug-apk` download করুন।
8. ZIP extract করে `app-debug.apk` Android phone-এ install করুন। Unknown app install permission চাইলে Android Settings থেকে অনুমতি দিন।

Build fail হলে Actions log-এর প্রথম `FAILURE:` বা `What went wrong:` অংশ কপি করে সাহায্য চান।
