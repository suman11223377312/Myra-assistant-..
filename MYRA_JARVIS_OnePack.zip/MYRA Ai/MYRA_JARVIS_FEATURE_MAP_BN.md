# MYRA AI — JARVIS Feature Map (স্ক্রিনশট ও অনুরোধ অনুযায়ী)

এই নথি MYRA-কে JARVIS-ধাঁচের assistant করার লক্ষ্য ও বাস্তবায়নের অগ্রাধিকার ধরে। **নিচের সবকিছু এখনই সম্পূর্ণ কাজ করে না**; status column-এ source-এর বর্তমান অবস্থা বলা হয়েছে।

| Feature | বর্তমান source অবস্থা | পরবর্তী কাজ |
|---|---|---|
| Gemini AI voice conversation | আংশিক source আছে | API/model compatibility, audio turn handling ও device test |
| Text chat + SEND | source-এ আছে | UI/voice response integration test |
| Bangla/Hindi/English | অসম্পূর্ণ | language selection, STT/TTS locale, prompt tests |
| Hey Mira wake word | অসম্পূর্ণ | on-device wake-word model, consent, battery tests |
| Open installed apps | command/launcher scaffolding | Hindi/Bangla command parsing ও app-label matching test |
| YouTube search/play | command path আছে | safe YouTube intent/deep-link handling; playback app-এর ওপর নির্ভরশীল |
| Flashlight ON/OFF | command path আছে | CameraManager implementation, hardware/permission/error handling test |
| Volume control | command path আছে | AudioManager implementation and device test |
| WhatsApp message | partial automation scaffolding | contact selection, preview, explicit send confirmation |
| WhatsApp/SMS notification read | permission/service work required | NotificationListenerService, privacy controls, per-app opt-in |
| AI auto-reply | screenshot concept; incomplete | default OFF, app/contact allowlist, message preview/confirmation |
| Call assistant | partial source | role/permission/device compatibility tests |
| Screen automation | Accessibility scaffolding | explicit user-triggered actions, robust UI matching and fail-safe |
| Screen lock | partial app/device-admin code | device admin consent; never claim secure phone unlock bypass |
| Themes Studio | screenshot shows design; incomplete in source | theme model, persisted selection, apply across screens |
| Mira avatar | screenshot shows design; incomplete in source | licensed/original assets, avatar selector, animation |
| Lip-sync/emotions | incomplete | audio amplitude/viseme pipeline and supported character rig |
| Particle spheres/logo orbs | screenshot shows design; incomplete in source | selectable renderers and voice-reactive animation |
| Reminder/calendar | not integrated | local notifications and optional calendar integration |
| Web search/weather | not integrated | explicit online search/weather provider and network/error handling |
| Camera/vision | partial OCR/screen vision classes | CameraX flow, runtime permissions, privacy UX |
| Floating assistant | partial overlay classes | overlay permission and lifecycle tests |
| Security | partial biometric/app-lock classes | secure storage, biometric fallback and threat review |

## Suggested implementation order
1. **Build reliability:** compile on GitHub Actions; resolve all build errors first.
2. **Core conversation:** Gemini connection, text chat, mic permission, playback/listening state and reconnect.
3. **Basic phone actions:** open app, flashlight, volume, YouTube search; every action reports success/failure honestly.
4. **Settings Studio UI:** themes, voice, language, avatar, wake-word and privacy controls.
5. **Messaging:** notification reading first; auto-reply only after explicit opt-in, allowlist and confirmation.
6. **Advanced JARVIS:** overlay, reminders, camera/vision, call assistant and memory.
7. **Device validation:** test on the target Android phone and record each feature as Pass/Partial/Blocked.

## Non-negotiable safety rules
- Do not auto-send messages, place calls, make purchases, or perform destructive actions without user confirmation.
- Do not store/read another person's messages beyond the notification permissions and app policies the user explicitly enabled.
- Never request or extract the Android lock PIN/pattern.
- Always provide a visible way to stop microphone listening and revoke permissions.

## নতুন Control Center-এ যোগ করা হয়েছে
- Installed app chooser এবং explicit launch
- Camera2 torch toggle with status/error feedback
- Media volume adjustment
- Android Wi-Fi/display settings shortcuts
- Camera launch and web search
- Local reminder notification and system alarm intent
- Persisted theme/avatar/language/personality choices
- Notification listener with opt-in TTS message reading and opt-in supported quick-reply action
- Notification/accessibility/overlay/app permission settings shortcuts

এগুলো source-level implementation। বাস্তব ফোনে permission, notification action support, manufacturer behavior এবং build পরীক্ষা এখনও প্রয়োজন। Hey MYRA always-on wake-word (including reliable screen-off/locked wake), real 3D character lip-sync, fully integrated theme rendering, and complete Gemini tool/function calling remain future implementation work and are not represented as finished. A normal Android app cannot power on a fully powered-off phone by voice.
